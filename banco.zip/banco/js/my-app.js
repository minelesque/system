// Initialize your app
var myApp = new Framework7({
    animateNavBackIcon:true,
    template7Pages: true,
    precompileTemplates: true
});

// Export selectors engine
var $$ = Dom7;

// Add main View
var mainView = myApp.addView('.view-main', {
    // Enable dynamic Navbar
    dynamicNavbar: true,
    // Enable Dom Cache so we can use all inline pages
    domCache: true
});

// @TODO Parse.com credentials
// Setup your Parse.com applicationId and API key 
var applicationId = 'xxx';
var restApiKey = 'yyy';


// Funcion to handle Cancel button on Login page
$$('#cancel-login').on('click', function () {
	// Clear field values
	$$('#login-email').val('');
	$$('#login-password').val('');
});

$$('#cancel-teste').on('click', function () {
	// Clear field values
	$$('#nome').val('');
	$$('#senha').val('');
});

//--------------------------------------------




$$('#enviar_teste').on('click', function () {
     
         $$.ajax({
            type: "POST",
            url: "http://10.0.0.16/estudo/banco/inserir.php", //estudo\banco
            data: {
                acao: 'testando',
                nome: $$("#nome").val(),
                senha: $$("#senha").val(),
                login: $$("#login").val(),
                telefone: $$("#telefone").val()
            },            
            async: false,
            dataType: "json", 
            success: function (json) {
 
                if(json.result == true){
                   //redireciona o usuario para pagina
                   $("#usuario_nome").html(json.dados.nome);
 
                   $.mobile.changePage("#index", {
                        transition : "slidefade"
                    });
 
                }else{
                   alert(json.msg);
                }
            },error: function(xhr,e,t){
                console.log(xhr.responseText);                
            }
        });
      });




$$('#pesquisa').on('click', function () {
	$$.ajax({
    url: 'http://10.0.0.16/estudo/banco/getdados.php',
    dataType: 'json', //or html
    timeout: 5000,
    success: function(dados){
     console.log('Funcionou!');

     for(var i=0;dados.length>i;i++){
				//Adicionando registros retornados na tabela
				$$('#tabela').append('<tr><td>'+dados[i].id+'</td><td>'+dados[i].nome+'</td><td>'+dados[i].login+'</td></tr>'+'</td><td>'+dados[i].senha+'</td></tr>'+'</td><td>'+dados[i].telefone+'</td></tr>');
			}

//success: function(dados){
			//for(var i=0;dados.length>i;i++){
				//Adicionando registros retornados na tabela
			//	$('#tabela').append('<tr><td>'+dados[i].id+'</td><td>'+dados[i].nome+'</td><td>'+dados[i].email+'</td></tr>');
			//}
      


    },
    error: function(){
      console.log('Deu erro!');
    }
});
});


//--------------------------------------------------

// Funcion to handle Submit button on Login page
$$('#submmit-login').on('click', function () {
    
    var username = $$('#login-email').val();
    var password = $$('#login-password').val();

    console.log('Submit clicked');
    console.log('username: ' +username);
    console.log('password: ' +password);

    var query = '10.0.0.16/login?username='+username+'&password='+password; 
    myApp.showIndicator();

    // Using Ajax for communication with Parse backend
    // Note mandatory headers with credentials required
    // by Parse. HTTP communication responses are handled
    // in success / error callbacks
	$$.ajax({
		url: query,
		headers: {"X-Parse-Application-Id":applicationId,"X-Parse-REST-API-Key":restApiKey},
	    type: "GET",
	    // if successful response received (http 2xx)
	    success: function(data, textStatus ){
	   		
	    	// We have received response and can hide activity indicator
	   		myApp.hideIndicator();
		
	   		data = JSON.parse(data);
	   		if (!data.username) {return}

	   		var username = data.username;		
			
			// Will pass context with retrieved user name 
			// to welcome page. Redirect to welcome page
			mainView.router.load({
				template: Template7.templates.welcomeTemplate,
				context: {
					name: username
				}
			});
	    },
	    error: function(xhr, textStatus, errorThrown){    	
	    	// We have received response and can hide activity indicator
	    	myApp.hideIndicator();		
			myApp.alert('Login was unsuccessful, please verify username and password and try again');

			$$('#login-email').val('');
			$$('#login-password').val('');
	    }
	});
});


// Function to handle Submit button on Register page
$$('#submmit-register').on('click', function () {
    
    var username = $$('#register-username').val();
    var email = $$('#register-email').val();
    var password = $$('#register-password').val();

    console.log('Submit clicked');
    console.log('username: ' +username+ 'and password: '+password+ 'and email: '+email);

    if (!username || !password || !email){
    	myApp.alert('Please fill in all Registration form fields');
    	return;
    }

   	// Methods to handle speciffic HTTP response codes
	var success201 = function(data, textStatus, jqXHR) {
		
		// We have received response and can hide activity indicator
	   	myApp.hideIndicator();

	   	console.log('Response body: '+data);				
			
		// Will pass context with retrieved user name 
		// to welcome page. Redirect to welcome page
		mainView.router.load({
			template: Template7.templates.welcomeTemplate,
			context: {
				name: username
			}
		});
	};

	var notsuccess = function(data, textStatus, jqXHR) {	
		// We have received response and can hide activity indicator
	    myApp.hideIndicator();		
		myApp.alert('Login was unsuccessful, please try again');
	};

    var query = 'https://api.parse.com/1/users';
    var postdata = {};
    postdata.username = username;
    postdata.password = password;
    postdata.email = email;

    myApp.showIndicator();

    // Using Ajax for communication with Parse backend
    // Note mandatory headers with credentials required
    // by Parse. HTTP communication responses are handled
    // based on HTTP response codes
	$$.ajax({
		url: query,
		headers: {"X-Parse-Application-Id":applicationId,"X-Parse-REST-API-Key":restApiKey},
	    type: "POST",
	    contentType: "application/json",
	    data: JSON.stringify(postdata),

	    statusCode: {
	    	201: success201,
	    	400: notsuccess,
	    	500: notsuccess
	    }
	});

});



